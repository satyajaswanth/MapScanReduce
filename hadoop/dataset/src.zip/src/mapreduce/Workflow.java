
package mapreduce;


public interface Workflow<K,V>
{
	
	public InCollector<K,V> run();
}
