
package mapreduce;


public interface Mapper<K,V>
{
	/**
	 * Map function
	 * @param c A {@link OutCollector} that will be used to write output tuples
	 * @param t A {@link Tuple} to process
	 */
	public void map(OutCollector<K,V> c, Tuple<K,V> t);
}
