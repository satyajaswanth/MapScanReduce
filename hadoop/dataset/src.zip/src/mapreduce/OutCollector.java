
package mapreduce;


public interface OutCollector<K,V>
{
	
	public void collect(Tuple<K,V> t);
	
	public void rewind();
}
