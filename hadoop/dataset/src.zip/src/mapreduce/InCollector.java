
package mapreduce;

import java.util.Iterator;


public interface InCollector<K,V> extends Iterator<Tuple<K,V>>
{
	
	public int count();
	
	
	public void rewind();
}
