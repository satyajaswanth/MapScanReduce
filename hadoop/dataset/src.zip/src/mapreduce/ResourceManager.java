
package mapreduce;

import java.util.LinkedList;
import java.util.List;


public class ResourceManager<K,V> {


  private int threadDefault = 100;


  private int threadMax = 0;


  private List<Thread> listThread = new LinkedList<Thread>();


  private void setThreadMax(int max)
  {
    this.threadMax = max;
  }

  public int getThreadMax()
  {
    return this.threadMax;
  }


  public ResourceManager()
  {
    setThreadMax(threadDefault);
  }


  public ResourceManager(int maxThread)
  {
    setThreadMax(maxThread);
  }


  public Thread getThread(Tuple<K,V> t, Collector<K,V> temp_coll, Mapper<K,V> m_mapper)
  {
    int i=0;
    boolean create = false;
    MapThread<K,V> MThread = null;
    Thread ThreadTemp = null;

    if(listThread.size() < threadMax)
    {
      MThread = new MapThread<K,V>(t,temp_coll,m_mapper);
      listThread.add(MThread);
    }
    else
    {
      while(create != true)
      {
        while(i < listThread.size())
        {
          ThreadTemp = listThread.get(i);

          if(!ThreadTemp.isAlive())
          {
            listThread.remove(i);
            MThread = new MapThread<K,V>(t,temp_coll,m_mapper);
            listThread.add(MThread);
            create = true;
            i = listThread.size();
          }
          else
          {
            i++;
          }
        }
        i = 0;
      }
    }
    return MThread;
  }

  /**
   * Creates a reducer thread
   * @param out The collector of the final results
   * @param key The key to reduce
   * @param s_source The collector of all results of the mapper phase
   * @param m_reducer The {@link Reducer} to use in the reduce phase
   * @return A thread
   */
  public Thread getThread(Collector<K,V> out,  K key, Collector<K,V> s_source, Reducer<K,V> m_reducer)
  {
    int i=0;
    boolean create = false;
    ReduceThread<K,V> RThread = null;
    Thread ThreadTemp = null;

    if(listThread.size() < threadMax)
    {
      RThread = new ReduceThread<K,V>(out, key, s_source, m_reducer);
      listThread.add(RThread);
    }
    else
    {
      while(create !=true)
      {
        while(i< listThread.size())
        {
          ThreadTemp = listThread.get(i);

          if(!ThreadTemp.isAlive())
          {
            listThread.remove(i);
            RThread = new ReduceThread<K,V>(out, key, s_source, m_reducer);
            listThread.add(RThread);
            create = true;
            i = listThread.size();
          }
          else
            i++;
        }
        i=0;
      }
    }
    return RThread;
  }

  /**
   * Function who check if all threads of the list are dead and clear the list
   */
  public void waitThreads()
  {
    int i=0;
    Thread ThreadTemp = null;
    while(i < listThread.size())
    {
      ThreadTemp = listThread.get(i);

      if(ThreadTemp.isAlive())
        i = 0;    
      else
        i++;
    }
    listThread.clear();
  }
}

/**
 * Class who encapsulates the processing of a mapper and his informations 
 * in a thread
 * @author Maxime Soucy-Boivin
 */
class MapThread<K,V> extends Thread 
{
  /**
   * Informations needed to be transferred to the mapper
   * For more information, see function getThread
   */
  Tuple<K,V> tThread = new Tuple<K,V>();
  Collector<K,V> Thread_Temp_col = new Collector<K,V>();
  Mapper<K,V> Thread_m_mapper = null;

  /**
   * Create an instance of MapThread
   * @param t The tuple to analyse
   * @param temp_coll The collector of all results
   * @param m_mapper The {@link Mapper} to use in the map phase
   */
  MapThread(Tuple<K,V> t, Collector<K,V> temp_coll, Mapper<K,V> m_mapper) 
  {
    this.tThread = t;
    this.Thread_Temp_col = temp_coll;
    this.Thread_m_mapper = m_mapper;
  }

  /**
   * Function who start the execution of the mapper
   */
  public void run() 
  {
    Thread_m_mapper.map(Thread_Temp_col, tThread);
  }
}

/**
 * Class who encapsulates the processing of a reducer and his informations
 * in a thread
 * @author Maxime Soucy-Boivin
 */
class ReduceThread<K,V> extends Thread 
{
  /**
   * Informations needed to be transferred to the reducer
   * For more information, see function getThread
   */
  Collector<K,V> outThread = new Collector<K,V>();
  K Thread_key = null;
  Collector<K,V> Thread_s_source = new Collector<K,V>();
  Reducer<K,V> Thread_m_reducer = null;

  /**
   * Create an instance of ReduceThread
   * @param out The collector of the final results
   * @param key The key to reduce
   * @param s_source The collector of all results of the mapper phase
   * @param m_reducer The {@link Reducer} to use in the reduce phase
   */
  ReduceThread(Collector<K,V> out, K key, Collector<K,V> s_source, Reducer<K,V> m_reducer) 
  {
    this.outThread = out;
    this.Thread_key = key;
    this.Thread_s_source = s_source;
    this.Thread_m_reducer = m_reducer;
  }

  /**
   * Function who start the execution of the reducer
   */
  public void run() 
  {
    Thread_m_reducer.reduce(outThread, Thread_key, Thread_s_source);
  }
}