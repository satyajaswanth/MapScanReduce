
package virualshuffling;


import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.SequenceFile;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.FileSplit;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.Partitioner;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.jfree.ui.RefineryUtilities;

public class Virtualshuffling extends Configured implements Tool {
  private static final Log LOG = LogFactory.getLog(Virtualshuffling.class);


  static class TotalOrderPartitioner implements Partitioner<Text,Text>{
    private balnacedTreeNode tree;
    private Text[] splitPoints;

   
    static abstract class balnacedTreeNode {
      private int level;
      balnacedTreeNode(int level) {
        this.level = level;
      }
      abstract int findPartition(Text key);
      abstract void print(PrintStream strm) throws IOException;
      int getLevel() {
        return level;
      }
    }

    static class InnerTreeNode extends balnacedTreeNode {
      private balnacedTreeNode[] child = new balnacedTreeNode[256];
      
      InnerTreeNode(int level) {
        super(level);
      }
      int findPartition(Text key) {
        int level = getLevel();
        if (key.getLength() <= level) {
          return child[0].findPartition(key);
        }
        return child[key.getBytes()[level]].findPartition(key);
      }
      void setChild(int idx, balnacedTreeNode child) {
        this.child[idx] = child;
      }
      void print(PrintStream strm) throws IOException {
        for(int ch=0; ch < 255; ++ch) {
          for(int i = 0; i < 2*getLevel(); ++i) {
            strm.print(' ');
          }
          strm.print(ch);
          strm.println(" ->");
          if (child[ch] != null) {
            child[ch].print(strm);
          }
        }
      }
    }
    
    class TreeNode {
	int val;
	TreeNode left;
	TreeNode right;
 
	TreeNode(int x) {
		val = x;
	}
}
    
    static class balancedsubtree
    {
        
        public boolean isBalanced(TreeNode SGB) {
		if (SGB == null)
			return true;
 
		if (getHeight(SGB) == -1)
			return false;
 
		return true;
	}
 
	public int getHeight(TreeNode SGB) {
		if (SGB == null)
			return 0;
 
		int SMBL = getHeight(SGB.left);
		int SMBR = getHeight(SGB.right);
 
		if (SMBL == -1 || SMBR == -1)
			return -1;
 
		if (Math.abs(SMBL - SMBR) > 1) {
			return -1;
		}
 
		return Math.max(SMBL, SMBR) + 1;
 
	}
    }
            

  
    static class LeafTreeNode extends balnacedTreeNode {
      int STB;
      int SEB;
      Text[] splitPoints;
      LeafTreeNode(int level, Text[] splitPoints, int lower, int upper) {
        super(level);
        this.splitPoints = splitPoints;
        this.STB = lower;
        this.SEB = upper;
      }
      int findPartition(Text key) {
        for(int i=STB; i<SEB; ++i) {
          if (splitPoints[i].compareTo(key) >= 0) {
            return i;
          }
        }
        return SEB;
      }
      void print(PrintStream strm) throws IOException {
        for(int i = 0; i < 2*getLevel(); ++i) {
          strm.print(' ');
        }
        strm.print(STB);
        strm.print(", ");
        strm.println(SEB);
      }
    }


    
    private static Text[] readPartitions(FileSystem fs, Path p, 
                                         JobConf job) throws IOException {
      SequenceFile.Reader reader = new SequenceFile.Reader(fs, p, job);
      List<Text> parts = new ArrayList<Text>();
      Text key = new Text();
      NullWritable value = NullWritable.get();
      while (reader.next(key, value)) {
        parts.add(key);
        key = new Text();
      }
      reader.close();
      return parts.toArray(new Text[parts.size()]);  
    }

   
    private static balnacedTreeNode buildTree(Text[] splits, int lower, int upper, 
                                      Text prefix, int maxDepth) {
      int depth = prefix.getLength();
      if (depth >= maxDepth || lower == upper) {
        return new LeafTreeNode(depth, splits, lower, upper);
      }
      InnerTreeNode result = new InnerTreeNode(depth);
      Text trial = new Text(prefix);
      // append an extra byte on to the prefix
      trial.append(new byte[1], 0, 1);
      int currentBound = lower;
      for(int ch = 0; ch < 255; ++ch) {
        trial.getBytes()[depth] = (byte) (ch + 1);
        lower = currentBound;
        while (currentBound < upper) {
          if (splits[currentBound].compareTo(trial) >= 0) {
            break;
          }
          currentBound += 1;
        }
        trial.getBytes()[depth] = (byte) ch;
        result.child[ch] = buildTree(splits, lower, currentBound, trial, 
                                     maxDepth);
      }
      
      trial.getBytes()[depth] = 127;
      result.child[255] = buildTree(splits, currentBound, upper, trial,
                                    maxDepth);
      return result;
    }

    public void configure(JobConf job) {
      try {
        FileSystem fs = FileSystem.getLocal(job);
        Path partFile = new Path(VirtualshufflingInputFormat.PARTITION_FILENAME);
        splitPoints = readPartitions(fs, partFile, job);
        tree = buildTree(splitPoints, 0, splitPoints.length, new Text(), 2);
      } catch (IOException ie) {
        throw new IllegalArgumentException("can't read paritions file", ie);
      }
    }

    public TotalOrderPartitioner() {
    }

    public int getPartition(Text key, Text value, int numPartitions) {
      return tree.findPartition(key);
    }
    
  }
  
  public int run(String[] args) throws Exception {
    LOG.info("starting");
    Random r=new Random();
    int outid=r.nextInt(1000);
    String ar[] = {"/usr/local/hadoop-2.7.2/app/healthcaredata1", "/media/4AD2B41FD2B41165/2015hadoopprojects/virtual scheduling/code/Virualshuffling/hdfs/vir" + outid};
    JobConf job = (JobConf) getConf();
    

    Path inputDir = new Path(ar[0]);
      long fz= FileUtils.sizeOfDirectory(new File(ar[0]));
   double mb=(1024*1024);
   double sz=fz/mb;
  //    System.out.println(""+sz);
    inputDir = inputDir.makeQualified(inputDir.getFileSystem(job));
    double st=System.currentTimeMillis();
    Path partitionFile = new Path(inputDir, VirtualshufflingInputFormat.PARTITION_FILENAME);
    URI partitionUri = new URI(partitionFile.toString() +
                               "#" + VirtualshufflingInputFormat.PARTITION_FILENAME);
    VirtualshufflingInputFormat.setInputPaths(job, new Path(ar[0]));
    FileOutputFormat.setOutputPath(job, new Path(ar[1]));
    job.setJobName("virtualshuffling");
    job.setJarByClass(Virtualshuffling.class);
    job.setOutputKeyClass(Text.class);
    job.setOutputValueClass(Text.class);
    job.setInputFormat(VirtualshufflingInputFormat.class);
    job.setOutputFormat(VirtualshufflingOutputFormat.class);
    job.setPartitionerClass(TotalOrderPartitioner.class);
    VirtualshufflingInputFormat.writePartitionFile(job, partitionFile);
    DistributedCache.addCacheFile(partitionUri, job);
    DistributedCache.createSymlink(job);
    job.setInt("dfs.replication", 1);
    VirtualshufflingOutputFormat.setFinalSync(job, true);
    JobClient.runJob(job);
    double end=System.currentTimeMillis();
     LOG.info("virtual shufffling Data size(MB):"+sz);
     double ext=(end-st);
     ext=ext/1000.0;
       final BarChart demo = new BarChart("virual shuffling Processing Time",ext,sz);
        demo.pack();
        RefineryUtilities.centerFrameOnScreen(demo);
        demo.setVisible(true);
    LOG.info("virtual shufffling Processing Time(seconds):"+ext);
    LOG.info("done");
    
    return 0;
  }

  /**
   * @param args
   */
  public static void main(String[] args) throws Exception {
    int res = ToolRunner.run(new JobConf(), new Virtualshuffling(), args);
   // System.exit(res);
  }

}
